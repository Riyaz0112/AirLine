package com.edubridge.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="airport_details")
public class Airport{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	@Column(name="airport_code",nullable = false)
	private Integer airportCode;
	
	@Column(name="airport_name",nullable=false)
	private String airportName;
	
	@Column(name="airport_city")
	private String airportCity;
	
	@Column(name="airport_state")
	private String airportState;
	
	@Column(name="airport_country")
	private String airportCountry;

	public Integer getAirportCode() {
		return airportCode;
	}

	public void setAirportCode(Integer airportCode) {
		this.airportCode = airportCode;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getAirportCity() {
		return airportCity;
	}

	public void setAirportCity(String airportCity) {
		this.airportCity = airportCity;
	}

	public String getAirportState() {
		return airportState;
	}

	public void setAirportState(String airportState) {
		this.airportState = airportState;
	}

	public String getAirportCountry() {
		return airportCountry;
	}

	public void setAirportCountry(String airportCountry) {
		this.airportCountry = airportCountry;
	}

	public Airport() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Airport(Integer airportCode, String airportName, String airportCity, String airportState,
			String airportCountry) {
		super();
		this.airportCode = airportCode;
		this.airportName = airportName;
		this.airportCity = airportCity;
		this.airportState = airportState;
		this.airportCountry = airportCountry;
	}

	@Override
	public String toString() {
		return "Airport [airportCode=" + airportCode + ", airportName=" + airportName + ", airportCity=" + airportCity
				+ ", airportState=" + airportState + ", airportCountry=" + airportCountry + "]";
	}

	
}
	